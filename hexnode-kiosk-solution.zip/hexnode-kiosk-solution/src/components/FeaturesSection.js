import React from "react";


function FeaturesSection() {
  return (
    <section id="features" className="features">
      <h2>Features</h2>
      <div className="feature-list">
        <div className="feature-item">
          <h3>Feature 1</h3>
          <p>Description of feature 1.</p>
        </div>
        <div className="feature-item">
          <h3>Feature 2</h3>
          <p>Description of feature 2.</p>
        </div>
      </div>
    </section>
  );
}

export default FeaturesSection;