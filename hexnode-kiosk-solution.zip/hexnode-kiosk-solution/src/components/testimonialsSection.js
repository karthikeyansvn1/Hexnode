import React from "react";


function TestimonialsSection() {
  return (
    <section id="testimonials" className="testimonials">
      <h2>What Our Users Say</h2>
      <div className="testimonial-list">
        <blockquote>
          <p>Hexnode has revolutionized our workflow!</p>
          <cite>- User 1</cite>
        </blockquote>
        <blockquote>
          <p>A must-have solution for any business.</p>
          <cite>- User 2</cite>
        </blockquote>
      </div>
    </section>
  );
}

export default TestimonialsSection;
