import React from "react";
import { useNavigate } from "react-router-dom";

function HeroSection() {
  const navigate = useNavigate();

  return (
    <section className="hero">
      <h1>Hexnode Kiosk Solution</h1>
      <p>Empower your workforce with the ultimate device management solution.</p>
      <button onClick={() => navigate("/get-started")}>Get Started</button>
    </section>
  );
}

export default HeroSection;
