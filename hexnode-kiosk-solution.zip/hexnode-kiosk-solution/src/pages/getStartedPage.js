import React from "react";
import "./getStartedPage.scss";

function GetStartedPage() {
  return (
    <div className="get-started-page">
      <h1>Welcome to the Get Started Page!</h1>
      <p>This page is designed to help you get started with Hexnode Kiosk Solution.</p>
      <button onClick={() => alert("Thanks for starting!")}>Get Started Now</button>
    </div>
  );
}

export default GetStartedPage;
