import React from "react";
import HeroSection from "../components/HeroSection";
import FeaturesSection from "../components/FeaturesSection";
import TestimonialsSection from "../components/testimonialsSection";
import ContactForm from "../components/ContactForm";
import "./HomePage.scss";

function HomePage() {
  return (
    <div className="home-page">
      <HeroSection />
      <FeaturesSection />
      <TestimonialsSection />
      <ContactForm />
    </div>
  );
}

export default HomePage;
